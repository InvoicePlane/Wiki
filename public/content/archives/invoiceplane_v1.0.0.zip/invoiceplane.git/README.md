![InvoicePlane](http://invoiceplane.com/content/logo/PNG/logo_300x150.png)
#### _Version 1.0.0_


InvoicePlane is a self-hosted open source application for managing your invoices, clients and payments.    
More Information on __[invoiceplane.com](https://invoiceplane.com)__

If you need support or want to help developing please visit the [official repository](https://repo.invoiceplane.com/ip/invoiceplane/wikis/home).

---

> *Please notice: The name (InvoicePlane) and the logo can be used but may not be changed / altered in any way.
The name and the logo are both original copyright by www.Kovah.de. For more information visit invoiceplane.com/license-copyright*

