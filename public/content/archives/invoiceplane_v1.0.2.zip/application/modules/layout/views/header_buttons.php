<div class="pull-right btn-group">
    <button id="btn-submit" name="btn_submit" class="btn btn-success btn-sm" value="1">
        <i class="fa fa-check"></i> <?php echo lang('save'); ?>
    </button>
    <button id="btn-cancel" name="btn_cancel" class="btn btn-danger btn-sm" value="1">
        <i class="fa fa-times"></i> <?php echo lang('cancel'); ?>
    </button>
</div>